
  # Mobile-Friendly Tutor Attendance App

  This is a code bundle for Mobile-Friendly Tutor Attendance App. The original project is available at https://www.figma.com/design/A7pEXDaaKDn2tla35zKo3x/Mobile-Friendly-Tutor-Attendance-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  